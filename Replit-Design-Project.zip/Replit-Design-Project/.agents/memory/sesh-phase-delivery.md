---
name: Sesh phase delivery
description: Delivery convention and integration boundary for work on Sesh.
---

Sesh is maintained in the user's separate Flask repository at `Miringuisthegoat/Sesh`. Its project decision log specifies phase deliverables as ZIP overlays. This Replit project does not contain the Flask application source.

**Why:** The user's linked repository and its decision log establish the source location and delivery convention; the Replit workspace contains only the API scaffold and design canvas.

**How to apply:** For Sesh phase work in this Replit project, keep changes compatible with the existing Flask routes and business rules, package them as an overlay, and do not claim to have changed the remote repository.
