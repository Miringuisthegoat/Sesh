# Sesh Phase 6 — Interface overlay

This overlay refreshes the Sesh web interface across authenticated and signed-out screens. It keeps the existing Flask routes, form fields, CSRF tokens, permission checks, and print/conversion status rules in place.

## Apply to the Sesh repository

1. Make a backup or commit the current Sesh project first.
2. Extract this ZIP into the Sesh project root and allow the included files to replace the matching files.
3. Run the existing test suite with `python -m pytest -q`.

The overlay replaces `app/templates/base.html`, `app/templates/dashboard.html`, and `app/static/app.css`, and adds `app/static/images/seshat-logo.webp`.

The shared base template and stylesheet carry the visual update through the existing document, upload, print, worker, office, company, audit, sign-in, setup, and error screens. The dashboard template adds the redesigned welcome and status overview while continuing to use the app's existing data.

No routes, database schema, conversion behavior, print-job transitions, or permissions are changed. The GitHub repository is not modified by this package.
