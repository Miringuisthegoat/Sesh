import {
  Activity, AlertCircle, ArrowDownToLine, ArrowLeft, ArrowRight, Bell, Check,
  CheckCircle2, ChevronDown, Clock3, FilePlus2, FileText, Filter, HardDrive,
  HelpCircle, History, Info, KeyRound, Laptop, LayoutDashboard, LockKeyhole,
  LogOut, Menu, Printer, RefreshCw, Search, Settings, ShieldCheck, Upload, UserPlus,
  Users, X,
} from "lucide-react";
import { useMemo, useRef, useState, type ChangeEvent, type DragEvent, type FormEvent } from "react";
import "./_group.css";

type Screen =
  | "dashboard" | "documents" | "upload" | "document-detail"
  | "queue" | "history" | "attention" | "new-print" | "job-detail"
  | "workers" | "password-reset" | "company" | "office-setup"
  | "agent-setup" | "printer-setup" | "audit" | "error" | "signin" | "first-setup";
type Role = "Administrator" | "Staff";
type JobState = "QUEUED" | "SENT_TO_PRINTER" | "DOWNLOADED" | "UNCERTAIN" | "CANCELLED";
type Job = { id: string; file: string; owner: string; pages: number; copies: number; printer: string; state: JobState; time: string; color: boolean; };
type Doc = { id: string; name: string; kind: string; size: string; owner: string; status: string; date: string; };

const initialDocs: Doc[] = [
  { id: "DOC-2418", name: "Q3 Office Expense Report.pdf", kind: "PDF", size: "2.4 MB", owner: "Mira Chen", status: "Ready to print", date: "Today, 10:42 AM" },
  { id: "DOC-2417", name: "Vendor agreement — Northline.docx", kind: "DOCX", size: "840 KB", owner: "Daniel Park", status: "Converted", date: "Today, 9:18 AM" },
  { id: "DOC-2416", name: "New starter checklist.xlsx", kind: "XLSX", size: "1.1 MB", owner: "Mira Chen", status: "Ready to print", date: "Yesterday, 4:36 PM" },
  { id: "DOC-2415", name: "Studio floor plan.pdf", kind: "PDF", size: "6.8 MB", owner: "Priya Nair", status: "Ready to print", date: "Yesterday, 2:02 PM" },
  { id: "DOC-2414", name: "Client brief — Alder House.pptx", kind: "PPTX", size: "3.2 MB", owner: "Daniel Park", status: "Converted", date: "Jun 16, 11:25 AM" },
  { id: "DOC-2413", name: "Benefits enrollment 2025.docx", kind: "DOCX", size: "510 KB", owner: "Mira Chen", status: "Ready to print", date: "Jun 15, 3:07 PM" },
];
const initialJobs: Job[] = [
  { id: "SJ-10842", file: "Q3 Office Expense Report.pdf", owner: "Mira Chen", pages: 18, copies: 2, printer: "Finance · HP LaserJet M607", state: "SENT_TO_PRINTER", time: "Today, 10:48 AM", color: false },
  { id: "SJ-10841", file: "Vendor agreement — Northline.pdf", owner: "Daniel Park", pages: 12, copies: 1, printer: "Main office · Canon C5840", state: "UNCERTAIN", time: "Today, 10:16 AM", color: true },
  { id: "SJ-10840", file: "New starter checklist.pdf", owner: "Mira Chen", pages: 4, copies: 4, printer: "Main office · Canon C5840", state: "QUEUED", time: "Today, 9:52 AM", color: false },
  { id: "SJ-10839", file: "Studio floor plan.pdf", owner: "Priya Nair", pages: 2, copies: 1, printer: "Design · Epson WF-C879R", state: "DOWNLOADED", time: "Yesterday, 4:22 PM", color: true },
  { id: "SJ-10838", file: "Alder House presentation.pdf", owner: "Daniel Park", pages: 26, copies: 1, printer: "Main office · Canon C5840", state: "DOWNLOADED", time: "Yesterday, 3:14 PM", color: true },
  { id: "SJ-10837", file: "June client invoices.pdf", owner: "Mira Chen", pages: 9, copies: 1, printer: "Finance · HP LaserJet M607", state: "CANCELLED", time: "Yesterday, 1:06 PM", color: false },
];
const screens: Record<string, { title: string; group: string }> = {
  dashboard: { title: "Dashboard", group: "Overview" },
  documents: { title: "Documents", group: "Documents" },
  upload: { title: "Upload files", group: "Documents" },
  "document-detail": { title: "Document preview", group: "Documents" },
  queue: { title: "Print queue", group: "Print coordination" },
  history: { title: "Print history", group: "Print coordination" },
  attention: { title: "Needs attention", group: "Print coordination" },
  "new-print": { title: "New print request", group: "Print coordination" },
  "job-detail": { title: "Print job", group: "Print coordination" },
  workers: { title: "Workers", group: "People" },
  "password-reset": { title: "Password reset", group: "People" },
  company: { title: "Company settings", group: "Administration" },
  "office-setup": { title: "Office setup", group: "Administration" },
  "agent-setup": { title: "Computer agent", group: "Administration" },
  "printer-setup": { title: "Printer setup", group: "Administration" },
  audit: { title: "Audit log", group: "Administration" },
  error: { title: "Something went wrong", group: "Help & system" },
};

function StatusBadge({ state }: { state: JobState | string }) {
  const style = state === "DOWNLOADED" || state === "Ready to print" || state === "Converted"
    ? "green" : state === "UNCERTAIN" ? "amber" : state === "CANCELLED" ? "neutral"
      : state === "SENT_TO_PRINTER" ? "amber" : "neutral";
  const label: Record<string, string> = {
    QUEUED: "Queued", SENT_TO_PRINTER: "Sent to printer", DOWNLOADED: "Downloaded by agent",
    UNCERTAIN: "Delivery uncertain", CANCELLED: "Cancelled", "Ready to print": "Ready to print", Converted: "Converted",
  };
  return <span className={`sesh-badge ${style}`}>{state === "DOWNLOADED" ? <CheckCircle2 /> : state === "UNCERTAIN" ? <AlertCircle /> : null}{label[state] || state}</span>;
}

function PageHead({ eyebrow, title, subtitle, children }: { eyebrow: string; title: string; subtitle: string; children?: React.ReactNode }) {
  return <div className="sesh-page-head"><div><p className="sesh-eyebrow">{eyebrow}</p><h1>{title}</h1><p>{subtitle}</p></div>{children && <div className="sesh-head-actions">{children}</div>}</div>;
}
function CardTitle({ title, description, action }: { title: string; description?: string; action?: React.ReactNode }) {
  return <div className="sesh-panel-head"><div><h2>{title}</h2>{description && <p>{description}</p>}</div>{action}</div>;
}

export function SeshPhase6() {
  const [screen, setScreen] = useState<Screen>("dashboard");
  const [role, setRole] = useState<Role>("Administrator");
  const [auth, setAuth] = useState(true);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [docs, setDocs] = useState(initialDocs);
  const [jobs, setJobs] = useState(initialJobs);
  const [activeDoc, setActiveDoc] = useState(initialDocs[0]);
  const [activeJobId, setActiveJobId] = useState("SJ-10841");
  const [search, setSearch] = useState("");
  const [docKind, setDocKind] = useState("All types");
  const [jobFilter, setJobFilter] = useState("All jobs");
  const [modal, setModal] = useState<"cancel" | "resolve" | "worker" | "invite" | null>(null);
  const [toast, setToast] = useState("");
  const [dragging, setDragging] = useState(false);
  const [selectedFile, setSelectedFile] = useState("");
  const [errorMode, setErrorMode] = useState(false);
  const [agentConnected, setAgentConnected] = useState(true);
  const [printerAvailable, setPrinterAvailable] = useState(true);
  const [companyName, setCompanyName] = useState("Seshat Studio");
  const [teamEmail, setTeamEmail] = useState("ops@seshat.studio");
  const [newWorker, setNewWorker] = useState({ name: "", email: "", role: "Staff" });
  const fileInputRef = useRef<HTMLInputElement>(null);
  const job = jobs.find((item) => item.id === activeJobId) || jobs[0];
  const current = screens[screen] || screens.dashboard;
  const isAdmin = role === "Administrator";
  const visibleDocs = useMemo(() => docs.filter((doc) =>
    (isAdmin || doc.owner === "Mira Chen") &&
    (doc.name.toLowerCase().includes(search.toLowerCase()) || doc.owner.toLowerCase().includes(search.toLowerCase())) &&
    (docKind === "All types" || doc.kind === docKind)), [docs, docKind, isAdmin, search]);
  const visibleJobs = useMemo(() => jobs.filter((item) =>
    (isAdmin || item.owner === "Mira Chen") &&
    (item.file.toLowerCase().includes(search.toLowerCase()) || item.id.toLowerCase().includes(search.toLowerCase()) || item.owner.toLowerCase().includes(search.toLowerCase())) &&
    (jobFilter === "All jobs" || item.state === jobFilter)), [jobs, isAdmin, jobFilter, search]);
  const activeJobs = visibleJobs.filter((item) => ["QUEUED", "SENT_TO_PRINTER", "UNCERTAIN"].includes(item.state));
  const attentionJobs = visibleJobs.filter((item) => item.state === "UNCERTAIN");
  const doneJobs = visibleJobs.filter((item) => ["DOWNLOADED", "CANCELLED"].includes(item.state));
  const ownedDocs = docs.filter((doc) => isAdmin || doc.owner === "Mira Chen");
  const ownedJobs = jobs.filter((item) => isAdmin || item.owner === "Mira Chen");

  function notify(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(""), 2800);
  }
  function navigate(next: Screen) {
    setScreen(next);
    setSearch("");
    if (next === "queue" || next === "history" || next === "attention") setJobFilter("All jobs");
    setMobileOpen(false);
    setModal(null);
    if (next === "error") setErrorMode(true); else setErrorMode(false);
  }
  function openJob(item: Job) { setActiveJobId(item.id); navigate("job-detail"); }
  function openDoc(item: Doc) { setActiveDoc(item); navigate("document-detail"); }
  function addFile(fileName: string) {
    if (!fileName) return;
    setSelectedFile(fileName);
    notify(`${fileName} is ready for local preview`);
  }
  function handleFileChange(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (file) addFile(file.name);
  }
  function handleDrop(event: DragEvent<HTMLDivElement>) {
    event.preventDefault(); setDragging(false);
    const file = event.dataTransfer.files?.[0];
    if (file) addFile(file.name);
  }
  function createLocalDocument() {
    if (!selectedFile) return;
    const next: Doc = { id: `DOC-${2420 + docs.length}`, name: selectedFile, kind: selectedFile.split(".").pop()?.toUpperCase() || "FILE", size: "Local file", owner: "Mira Chen", status: "Ready to print", date: "Just now" };
    setDocs((old) => [next, ...old]); setActiveDoc(next); setSelectedFile(""); navigate("document-detail");
    notify("Added to this preview session only");
  }
  function submitPrint(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const selectedDoc = String(data.get("file") || "Q3 Office Expense Report.pdf");
    const printer = String(data.get("printer") || "Main office · Canon C5840");
    const copies = Number(data.get("copies") || 1);
    const next: Job = { id: `SJ-${10843 + jobs.length}`, file: selectedDoc, owner: "Mira Chen", pages: selectedDoc.includes("Expense") ? 18 : 6, copies, printer, state: "QUEUED", time: "Just now", color: data.get("color") === "on" };
    setJobs((old) => [next, ...old]); setActiveJobId(next.id); navigate("job-detail"); notify("Print request added to this preview session");
  }
  function cancelJob() {
    if (!job || job.state === "DOWNLOADED") return;
    setJobs((old) => old.map((item) => item.id === job.id ? { ...item, state: "CANCELLED" } : item));
    setModal(null); notify("Job marked cancelled in this preview");
  }
  function resolveJob(outcome: "sent" | "retry") {
    if (!job) return;
    setJobs((old) => old.map((item) => item.id === job.id ? { ...item, state: outcome === "sent" ? "SENT_TO_PRINTER" : "QUEUED" } : item));
    setModal(null); notify(outcome === "sent" ? "Marked as sent to printer — output not confirmed" : "Returned to queue in this preview");
  }
  function addWorker(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setModal(null); setNewWorker({ name: "", email: "", role: "Staff" }); notify("Worker invitation preview created");
  }

  const navGroups = [
    { label: "Workspace", items: [{ id: "dashboard", text: "Dashboard", icon: LayoutDashboard }, { id: "documents", text: "Documents", icon: FileText }, { id: "upload", text: "Upload files", icon: Upload }] },
    { label: "Print coordination", items: [{ id: "queue", text: "Print queue", icon: Printer, count: activeJobs.length }, { id: "history", text: "History", icon: History }, { id: "attention", text: "Needs attention", icon: AlertCircle, count: attentionJobs.length }, { id: "new-print", text: "New print request", icon: FilePlus2 }] },
    ...(isAdmin ? [{ label: "Administration", items: [{ id: "workers", text: "Workers", icon: Users }, { id: "company", text: "Company settings", icon: Settings }, { id: "office-setup", text: "Office & devices", icon: Laptop }, { id: "audit", text: "Audit log", icon: ShieldCheck }] }] : []),
    { label: "Help & system", items: [{ id: "error", text: "Error screen", icon: HelpCircle }] },
  ];

  if (!auth) return <div className="sesh-app"><AuthScreen mode={screen === "first-setup" ? "setup" : "signin"} setMode={(mode) => setScreen(mode === "setup" ? "first-setup" : "signin")} onContinue={() => { setAuth(true); navigate(screen === "first-setup" ? "office-setup" : "dashboard"); }} /></div>;
  if (screen === "first-setup") return <div className="sesh-app"><AuthScreen mode="setup" setMode={(mode) => { if (mode === "signin") navigate("dashboard"); }} onContinue={() => navigate("office-setup")} /></div>;
  if (errorMode || screen === "error") return <div className="sesh-app"><div className="sesh-error-screen"><div className="sesh-error-inner"><div className="sesh-error-code">4<span style={{ color: "var(--accent)" }}>0</span>8</div><h1>That didn’t go as planned.</h1><p>The preview could not complete this request. Your existing files and print job states are unchanged.</p><button className="sesh-btn primary" onClick={() => { setErrorMode(false); navigate("dashboard"); }}><RefreshCw /> Return to dashboard</button><div style={{ marginTop: 11 }}><button className="sesh-btn ghost" onClick={() => notify("Nothing changed in this local preview")}><HelpCircle /> View troubleshooting note</button></div></div></div>{toast && <div className="sesh-toast" role="status">{toast}</div>}</div>;

  const page = () => {
    if (screen === "dashboard") return <Dashboard isAdmin={isAdmin} jobs={ownedJobs} docs={ownedDocs} onNavigate={navigate} onJob={openJob} onDoc={openDoc} agentConnected={agentConnected} printerAvailable={printerAvailable} />;
    if (screen === "documents") return <DocumentsPage docs={visibleDocs} search={search} setSearch={setSearch} kind={docKind} setKind={setDocKind} onUpload={() => navigate("upload")} onOpen={openDoc} />;
    if (screen === "upload") return <UploadPage selectedFile={selectedFile} fileInputRef={fileInputRef} dragging={dragging} setDragging={setDragging} handleFileChange={handleFileChange} handleDrop={handleDrop} onSample={() => addFile("Quarterly planning brief.docx")} onClear={() => setSelectedFile("")} onAdd={createLocalDocument} />;
    if (screen === "document-detail") return <DocumentDetail doc={activeDoc} onBack={() => navigate("documents")} onPrint={() => navigate("new-print")} onDownload={() => notify("Download is represented in this visual preview")} />;
    if (screen === "queue" || screen === "history" || screen === "attention") {
      const list = screen === "queue" ? activeJobs : screen === "history" ? doneJobs : attentionJobs;
      const heading = screen === "queue" ? "Print queue" : screen === "history" ? "Print history" : "Needs attention";
      const desc = screen === "queue" ? "Track work moving between the office computer and printer." : screen === "history" ? "A record of completed and cancelled print requests." : "Review jobs where delivery to the printer could not be confirmed.";
      return <JobsPage title={heading} description={desc} list={list} search={search} setSearch={setSearch} filter={jobFilter} setFilter={setJobFilter} onNew={() => navigate("new-print")} onOpen={openJob} />;
    }
    if (screen === "new-print") return <NewPrintPage docs={ownedDocs} onSubmit={submitPrint} onCancel={() => navigate("queue")} />;
    if (screen === "job-detail") return <JobDetail item={job} onBack={() => navigate("queue")} onCancel={() => setModal("cancel")} onResolve={() => setModal("resolve")} onResubmit={() => { const next = { ...job, id: `SJ-${10843 + jobs.length}`, state: "QUEUED" as JobState, time: "Just now" }; setJobs((old) => [next, ...old]); setActiveJobId(next.id); notify("Resubmitted in this preview; original job preserved"); }} />;
    if (screen === "workers") return <WorkersPage onInvite={() => setModal("invite")} onReset={() => navigate("password-reset")} />;
    if (screen === "password-reset") return <PasswordReset onBack={() => navigate("workers")} notify={notify} />;
    if (screen === "company") return <CompanySettings companyName={companyName} setCompanyName={setCompanyName} email={teamEmail} setEmail={setTeamEmail} notify={notify} onOffice={() => navigate("office-setup")} />;
    if (screen === "office-setup") return <OfficeSetup onAgent={() => navigate("agent-setup")} onPrinter={() => navigate("printer-setup")} agentConnected={agentConnected} printerAvailable={printerAvailable} />;
    if (screen === "agent-setup") return <AgentSetup connected={agentConnected} setConnected={setAgentConnected} onBack={() => navigate("office-setup")} notify={notify} />;
    if (screen === "printer-setup") return <PrinterSetup available={printerAvailable} setAvailable={setPrinterAvailable} onBack={() => navigate("office-setup")} notify={notify} />;
    if (screen === "audit") return <AuditPage />;
    return null;
  };

  return <div className="sesh-app">
    <div className={`sesh-mobile-scrim ${mobileOpen ? "visible" : ""}`} onClick={() => setMobileOpen(false)} aria-hidden="true" />
    <div className="sesh-shell">
      <aside className={`sesh-sidebar ${mobileOpen ? "open" : ""}`} aria-label="Main navigation">
        <div className="sesh-brand"><img src="/__mockup/images/seshat-logo.webp" alt="Seshat" /><div><strong>sesh</strong><small>OFFICE PRINT, IN ORDER</small></div></div>
        <div className="sesh-nav-scroll">{navGroups.map((group) => <div key={group.label}><div className="sesh-nav-label">{group.label}</div>{group.items.map((item) => {
          const Icon = item.icon; const active = screen === item.id || (screen === "job-detail" && item.id === "queue") || (screen === "document-detail" && item.id === "documents");
          return <button key={item.id} className={`sesh-nav-item ${active ? "active" : ""}`} onClick={() => navigate(item.id as Screen)} aria-current={active ? "page" : undefined}><Icon />{item.text}{item.count ? <span className="sesh-nav-count">{item.count}</span> : null}</button>;
        })}</div>)}
          <div className="sesh-nav-label">Account</div>
          <button className={`sesh-nav-item ${screen === "password-reset" ? "active" : ""}`} onClick={() => navigate("password-reset")}><KeyRound />Password reset</button>
          <button className="sesh-nav-item" onClick={() => navigate("first-setup")}><RefreshCw />First-time setup</button>
        </div>
        <div className="sesh-sidebar-foot"><div className="sesh-local-note"><Info />Visual preview · actions stay in this session</div><div className="sesh-user-row"><div className="sesh-avatar">MC</div><div><strong>Mira Chen</strong><small>{role} · Seshat Studio</small></div><button className="sesh-icon-btn" style={{ marginLeft: "auto", width: 29, height: 29 }} aria-label="Sign out" onClick={() => { setAuth(false); setScreen("signin"); }}><LogOut /></button></div><label className="sesh-mobile-role-label" htmlFor="mobile-role-switch">Preview role</label><select id="mobile-role-switch" className="sesh-role-select sesh-mobile-role" value={role} onChange={(event) => { setRole(event.target.value as Role); notify(event.target.value === "Staff" ? "Staff view: showing Mira’s records" : "Administrator view: company records visible"); }} aria-label="Switch preview role"><option>Administrator</option><option>Staff</option></select></div>
      </aside>
      <main className="sesh-main">
        <header className="sesh-topbar">
          <div className="sesh-top-left"><button className="sesh-icon-btn sesh-mobile-toggle" onClick={() => setMobileOpen(true)} aria-label="Open navigation"><Menu /></button><div className="sesh-breadcrumb"><span className="sesh-breadcrumb-group">{current.group}<span style={{ margin: "0 7px", color: "#c5c4bf" }}>/</span></span><b>{current.title}</b></div></div>
          <div className="sesh-top-actions">
            <button className="sesh-icon-btn" aria-label="Needs attention" onClick={() => navigate("attention")}><Bell /></button>
            <label className="sr-only" htmlFor="role-switch">Preview role</label>
            <select id="role-switch" className="sesh-role-select" value={role} onChange={(event) => { setRole(event.target.value as Role); notify(event.target.value === "Staff" ? "Staff view: showing Mira’s records" : "Administrator view: company records visible"); }} aria-label="Switch preview role"><option>Administrator</option><option>Staff</option></select>
            <div className="sesh-header-user"><div className="sesh-avatar">MC</div><div className="user-copy"><strong>Mira Chen</strong><small>{role}</small></div><ChevronDown size={13} color="#8e9490" /></div>
          </div>
        </header>
        <div className="sesh-content">{page()}</div>
      </main>
    </div>
    {modal && <Modal type={modal} job={job} worker={newWorker} onWorker={setNewWorker} onClose={() => setModal(null)} onCancel={cancelJob} onResolve={resolveJob} onInvite={addWorker} />}
    {toast && <div className="sesh-toast" role="status">{toast}</div>}
  </div>;
}

function Dashboard({ isAdmin, jobs, docs, onNavigate, onJob, onDoc, agentConnected, printerAvailable }: {
  isAdmin: boolean; jobs: Job[]; docs: Doc[]; onNavigate: (screen: Screen) => void; onJob: (job: Job) => void; onDoc: (doc: Doc) => void; agentConnected: boolean; printerAvailable: boolean;
}) {
  const sent = jobs.filter((job) => job.state === "SENT_TO_PRINTER").length;
  const awaiting = jobs.filter((job) => job.state === "QUEUED").length;
  const attention = jobs.filter((job) => job.state === "UNCERTAIN").length;
  return <>
    <div className="sesh-welcome"><div className="sesh-welcome-content"><p className="sesh-eyebrow">YOUR OFFICE, AT A GLANCE</p><h2>Good morning, Mira.</h2><p>{isAdmin ? "Your team’s documents and print work, all moving in one dependable place." : "Your documents and print requests, ready when you need them."}</p><button className="sesh-btn" onClick={() => onNavigate("new-print")}><Printer /> Start a print request</button></div><img className="sesh-welcome-mark" src="/__mockup/images/seshat-logo.webp" alt="" /></div>
    <div className="sesh-grid stats">
      <Stat icon={<FileText />} label="Documents this week" value={docs.length + 18} helper="Across your workspace" />
      <Stat icon={<Printer />} label="Sent to printer" value={sent + 12} helper="Printer output not confirmed" />
      <Stat icon={<Clock3 />} label="Waiting in queue" value={awaiting + 2} helper="Ready for the office agent" />
      <Stat icon={<AlertCircle />} label="Needs a look" value={attention} helper={attention ? "One delivery needs review" : "No uncertain deliveries"} />
    </div>
    <div className="sesh-dashboard-grid">
      <section className="sesh-card sesh-panel">
        <CardTitle title="Recent print activity" description="Live view of the handoff between your office computer and printer." action={<button className="sesh-inline-link" onClick={() => onNavigate("queue")}>View queue <ArrowRight size={12} /></button>} />
        <div className="sesh-table-wrap"><table className="sesh-table"><thead><tr><th>Document</th><th>Requested by</th><th>State</th><th>When</th></tr></thead><tbody>{jobs.slice(0,4).map((item) => <tr className="clickable" key={item.id} onClick={() => onJob(item)}><td><div className="sesh-file-name"><span className="sesh-file-icon"><FileText /></span><span>{item.file}<small>{item.id} · {item.copies} {item.copies === 1 ? "copy" : "copies"}</small></span></div></td><td>{item.owner}</td><td><StatusBadge state={item.state} /></td><td>{item.time}</td></tr>)}</tbody></table></div>
      </section>
      <div className="sesh-grid" style={{ alignContent: "start" }}>
        <section className="sesh-card sesh-panel"><CardTitle title="Office devices" description="Connection and print availability are separate." action={<button className="sesh-inline-link" onClick={() => onNavigate("office-setup")}>Manage</button>} />
          <div className="sesh-device-row"><span className="sesh-device-icon"><Laptop /></span><div className="sesh-device-copy"><strong>Studio-Mac-04</strong><small><i className={`sesh-dot ${agentConnected ? "" : "red"}`} />{agentConnected ? "Agent connected" : "Agent disconnected"} · checked just now</small></div></div>
          <div className="sesh-device-row"><span className="sesh-device-icon"><Printer /></span><div className="sesh-device-copy"><strong>Canon imageRUNNER C5840</strong><small><i className={`sesh-dot ${printerAvailable ? "" : "amber"}`} />{printerAvailable ? "Available · Main office" : "Unavailable · Main office"}</small></div></div>
        </section>
        <section className="sesh-card sesh-panel"><CardTitle title="Needs attention" action={<button className="sesh-inline-link" onClick={() => onNavigate("attention")}>See all</button>} />
          {jobs.filter((item) => item.state === "UNCERTAIN").length ? jobs.filter((item) => item.state === "UNCERTAIN").slice(0,2).map((item) => <div className="sesh-activity" key={item.id}><span className="sesh-activity-mark" /><div><strong>{item.file}</strong><small>Delivery uncertain · {item.time}</small><div style={{ marginTop: 7 }}><button className="sesh-inline-link" style={{ padding: 0 }} onClick={() => onJob(item)}>Review job</button></div></div></div>) : <p style={{ color: "var(--muted)", fontSize: 10 }}>No uncertain deliveries right now.</p>}
        </section>
      </div>
    </div>
    <section className="sesh-card sesh-panel" style={{ marginTop: 15 }}>
      <CardTitle title="Recently added documents" description="Your team’s latest converted files." action={<button className="sesh-inline-link" onClick={() => onNavigate("documents")}>All documents <ArrowRight size={12} /></button>} />
      <div className="sesh-table-wrap"><table className="sesh-table"><thead><tr><th>File</th><th>Owner</th><th>Added</th><th>Status</th></tr></thead><tbody>{docs.slice(0,3).map((doc) => <tr className="clickable" key={doc.id} onClick={() => onDoc(doc)}><td><div className="sesh-file-name"><span className="sesh-file-icon"><FileText /></span>{doc.name}</div></td><td>{doc.owner}</td><td>{doc.date}</td><td><StatusBadge state={doc.status} /></td></tr>)}</tbody></table></div>
    </section>
  </>;
}
function Stat({ icon, label, value, helper }: { icon: React.ReactNode; label: string; value: number; helper: string }) {
  return <div className="sesh-card sesh-stat"><div className="sesh-stat-top"><span>{label}</span><span className="sesh-stat-icon">{icon}</span></div><strong>{value}</strong><small>{helper}</small></div>;
}

function DocumentsPage({ docs, search, setSearch, kind, setKind, onUpload, onOpen }: { docs: Doc[]; search: string; setSearch: (s: string) => void; kind: string; setKind: (s: string) => void; onUpload: () => void; onOpen: (doc: Doc) => void; }) {
  return <>
    <PageHead eyebrow="DOCUMENT LIBRARY" title="Documents" subtitle="Files are converted to dependable, print-ready PDFs." ><button className="sesh-btn primary" onClick={onUpload}><Upload /> Upload files</button></PageHead>
    <section className="sesh-card sesh-panel">
      <div className="sesh-toolbar"><div className="sesh-search"><Search /><input className="sesh-input" type="search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search files or people…" aria-label="Search documents" /></div><select className="sesh-select sesh-filter" value={kind} onChange={(e) => setKind(e.target.value)} aria-label="Filter by file type"><option>All types</option><option>PDF</option><option>DOCX</option><option>XLSX</option><option>PPTX</option></select><span style={{ color: "var(--muted)", fontSize: 10, marginLeft: "auto" }}>{docs.length} files</span></div>
      {docs.length ? <div className="sesh-table-wrap"><table className="sesh-table"><thead><tr><th>Document</th><th>Owner</th><th>Added</th><th>File size</th><th>State</th><th></th></tr></thead><tbody>{docs.map((doc) => <tr key={doc.id} className="clickable" onClick={() => onOpen(doc)}><td><div className="sesh-file-name"><span className="sesh-file-icon"><FileText /></span><span>{doc.name}<small>{doc.id} · {doc.kind}</small></span></div></td><td>{doc.owner}</td><td>{doc.date}</td><td>{doc.size}</td><td><StatusBadge state={doc.status} /></td><td><button className="sesh-icon-btn" aria-label={`Open ${doc.name}`} onClick={(e) => { e.stopPropagation(); onOpen(doc); }}><ArrowRight /></button></td></tr>)}</tbody></table></div> : <Empty icon={<Search />} title="No matching files" detail="Try another search term or file type." />}
    </section>
  </>;
}

function UploadPage({ selectedFile, fileInputRef, dragging, setDragging, handleFileChange, handleDrop, onSample, onClear, onAdd }: {
  selectedFile: string; fileInputRef: React.RefObject<HTMLInputElement | null>; dragging: boolean; setDragging: (v: boolean) => void; handleFileChange: (e: ChangeEvent<HTMLInputElement>) => void; handleDrop: (e: DragEvent<HTMLDivElement>) => void; onSample: () => void; onClear: () => void; onAdd: () => void;
}) {
  return <>
    <PageHead eyebrow="DOCUMENT LIBRARY" title="Upload files" subtitle="Add a document and Sesh will prepare it for office printing."><button className="sesh-btn secondary" onClick={() => onClear()}><ArrowLeft /> Clear selection</button></PageHead>
    <div className="sesh-notice"><Info /> Files in this prototype are not sent to a server. Choose a local file or use a sample to preview the flow.</div>
    <section className="sesh-card sesh-panel">
      {!selectedFile ? <div className={`sesh-upload-zone ${dragging ? "dragging" : ""}`} role="button" tabIndex={0} onClick={() => fileInputRef.current?.click()} onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") fileInputRef.current?.click(); }} onDragOver={(e) => { e.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={handleDrop}>
        <div><div className="sesh-upload-symbol"><Upload /></div><strong>Drop a file here or browse</strong><p>PDF, Word, Excel, and PowerPoint · up to 25 MB</p><button className="sesh-btn secondary" type="button">Choose file</button></div>
      </div> : <div className="sesh-upload-zone" style={{ cursor: "default", borderStyle: "solid" }}><div><div className="sesh-upload-symbol"><FileText /></div><strong>{selectedFile}</strong><p>File selected for this preview session</p><button className="sesh-btn secondary" onClick={onClear}>Remove file</button></div></div>}
      <input ref={fileInputRef} type="file" accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx" hidden onChange={handleFileChange} />
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 16, gap: 10, flexWrap: "wrap" }}><button className="sesh-inline-link" onClick={onSample}>Use a sample document instead</button><button className="sesh-btn primary" disabled={!selectedFile} onClick={onAdd}>Prepare document <ArrowRight /></button></div>
    </section>
  </>;
}
function DocumentDetail({ doc, onBack, onPrint, onDownload }: { doc: Doc; onBack: () => void; onPrint: () => void; onDownload: () => void; }) {
  return <>
    <PageHead eyebrow="DOCUMENT PREVIEW" title={doc.name} subtitle={`${doc.id} · Uploaded by ${doc.owner} · ${doc.date}`}><button className="sesh-btn secondary" onClick={onBack}><ArrowLeft /> Back to documents</button><button className="sesh-btn secondary" onClick={onDownload}><ArrowDownToLine /> Download PDF</button><button className="sesh-btn primary" onClick={onPrint}><Printer /> Print this file</button></PageHead>
    <div className="sesh-detail-layout"><section className="sesh-card" style={{ padding: 12 }}><div className="sesh-preview"><article className="sesh-paper-preview"><div className="paper-kicker">Seshat Studio · Internal</div><h3>{doc.name.replace(/\.[^.]+$/, "")}</h3><p>Prepared for the Seshat Studio team. This preview represents the converted, print-ready document.</p><div className="sesh-paper-rule" /><p>SUMMARY &amp; DETAILS</p><div className="sesh-paper-lines"><span /><span /><span /><span /><span /><span /><span /></div><div className="sesh-paper-rule" /><p style={{ marginTop: 24 }}>Prepared with Sesh · {doc.date}</p></article></div></section>
      <div className="sesh-grid" style={{ alignContent: "start" }}><section className="sesh-card sesh-panel"><CardTitle title="File details" /><dl className="sesh-detail-list"><div><dt>Format</dt><dd>{doc.kind} → PDF</dd></div><div><dt>Original size</dt><dd>{doc.size}</dd></div><div><dt>Uploaded by</dt><dd>{doc.owner}</dd></div><div><dt>Added</dt><dd>{doc.date}</dd></div><div><dt>Document state</dt><dd><StatusBadge state={doc.status} /></dd></div></dl></section><section className="sesh-card sesh-panel"><CardTitle title="Print guidance" /><p style={{ color: "var(--muted)", fontSize: 10, margin: "0 0 11px" }}>A successful handoff means the office agent sent this PDF to the selected printer. It does not confirm pages have physically printed.</p><button className="sesh-btn primary" style={{ width: "100%" }} onClick={onPrint}><Printer /> Create print request</button></section></div>
    </div>
  </>;
}

function JobsPage({ title, description, list, search, setSearch, filter, setFilter, onNew, onOpen }: { title: string; description: string; list: Job[]; search: string; setSearch: (v: string) => void; filter: string; setFilter: (v: string) => void; onNew: () => void; onOpen: (job: Job) => void; }) {
  const tabs = title === "Print queue" ? ["All jobs", "QUEUED", "SENT_TO_PRINTER", "UNCERTAIN"] : title === "Print history" ? ["All jobs", "DOWNLOADED", "CANCELLED"] : ["All jobs", "UNCERTAIN"];
  const tabLabel: Record<string,string> = { "All jobs": "All jobs", QUEUED: "Queued", SENT_TO_PRINTER: "Sent to printer", UNCERTAIN: "Uncertain", DOWNLOADED: "Downloaded", CANCELLED: "Cancelled" };
  const filtered = filter === "All jobs" ? list : list.filter((item) => item.state === filter);
  return <>
    <PageHead eyebrow="PRINT COORDINATION" title={title} subtitle={description}><button className="sesh-btn primary" onClick={onNew}><FilePlus2 /> New print request</button></PageHead>
    <section className="sesh-card sesh-panel">
      <div className="sesh-tabs" role="tablist" aria-label="Filter print jobs">{tabs.map((tab) => <button key={tab} role="tab" aria-selected={filter === tab} className={`sesh-tab ${filter === tab ? "active" : ""}`} onClick={() => setFilter(tab)}>{tabLabel[tab]}</button>)}</div>
      <div className="sesh-toolbar"><div className="sesh-search"><Search /><input className="sesh-input" type="search" placeholder="Search job, file, or person…" value={search} onChange={(e) => setSearch(e.target.value)} aria-label="Search print jobs" /></div><span style={{ color: "var(--muted)", fontSize: 10, marginLeft: "auto" }}>{filtered.length} requests</span></div>
      {filtered.length ? <div className="sesh-table-wrap"><table className="sesh-table"><thead><tr><th>Job / document</th><th>Requested by</th><th>Printer</th><th>Copies</th><th>State</th><th>Requested</th></tr></thead><tbody>{filtered.map((item) => <tr className="clickable" key={item.id} onClick={() => onOpen(item)}><td><div className="sesh-file-name"><span className="sesh-file-icon"><Printer /></span><span>{item.file}<small>{item.id} · {item.pages} pages</small></span></div></td><td>{item.owner}</td><td>{item.printer}</td><td>{item.copies}</td><td><StatusBadge state={item.state} /></td><td>{item.time}</td></tr>)}</tbody></table></div> : <Empty icon={<Filter />} title="No jobs in this view" detail="Try another tab or start a new print request." action={<button className="sesh-btn primary" onClick={onNew}><FilePlus2 /> New print request</button>} />}
    </section>
  </>;
}
function NewPrintPage({ docs, onSubmit, onCancel }: { docs: Doc[]; onSubmit: (e: FormEvent<HTMLFormElement>) => void; onCancel: () => void; }) {
  return <>
    <PageHead eyebrow="PRINT COORDINATION" title="New print request" subtitle="Choose a converted document and a destination printer." />
    <div className="sesh-notice"><Info /> Local preview only. This form creates a sample job in this browser session; no printer receives it.</div>
    <form className="sesh-card sesh-panel" onSubmit={onSubmit} style={{ maxWidth: 820 }}>
      <div className="sesh-form-grid">
        <div className="sesh-field full"><label htmlFor="print-file">Document</label><select className="sesh-select" id="print-file" name="file" required defaultValue={docs[0]?.name || ""}>{docs.map((doc) => <option key={doc.id} value={doc.name}>{doc.name} · {doc.owner}</option>)}</select><small>Only converted, print-ready files appear here.</small></div>
        <div className="sesh-field"><label htmlFor="print-printer">Printer</label><select className="sesh-select" id="print-printer" name="printer"><option>Main office · Canon C5840</option><option>Finance · HP LaserJet M607</option><option>Design · Epson WF-C879R</option></select></div>
        <div className="sesh-field"><label htmlFor="print-copies">Copies</label><input className="sesh-input" id="print-copies" name="copies" type="number" min="1" max="99" defaultValue="1" /></div>
        <div className="sesh-field"><label htmlFor="print-range">Page range</label><input className="sesh-input" id="print-range" name="range" placeholder="All pages" /></div>
        <div className="sesh-field"><label htmlFor="print-duplex">Sides</label><select className="sesh-select" id="print-duplex" name="sides"><option>Two-sided</option><option>One-sided</option></select></div>
        <div className="sesh-field full"><label style={{ display: "flex", gap: 8, alignItems: "center", fontWeight: 500 }}><input name="color" type="checkbox" /> Print in color</label><small>Paper output is not confirmed by a successful send state.</small></div>
      </div>
      <div className="sesh-form-actions"><button type="button" className="sesh-btn secondary" onClick={onCancel}>Cancel</button><button className="sesh-btn primary" type="submit"><Printer /> Create request</button></div>
    </form>
  </>;
}
function JobDetail({ item, onBack, onCancel, onResolve, onResubmit }: { item: Job; onBack: () => void; onCancel: () => void; onResolve: () => void; onResubmit: () => void; }) {
  const canCancel = item.state !== "DOWNLOADED" && item.state !== "CANCELLED";
  return <>
    <PageHead eyebrow={`PRINT JOB · ${item.id}`} title={item.file} subtitle={`Requested by ${item.owner} · ${item.time}`}><button className="sesh-btn secondary" onClick={onBack}><ArrowLeft /> Back</button>{item.state === "UNCERTAIN" && <button className="sesh-btn primary" onClick={onResolve}><AlertCircle /> Resolve uncertainty</button>}{item.state === "CANCELLED" && <button className="sesh-btn primary" onClick={onResubmit}><RefreshCw /> Resubmit</button>}<button className="sesh-btn danger" disabled={!canCancel} title={item.state === "DOWNLOADED" ? "Downloaded jobs cannot be cancelled." : undefined} onClick={onCancel}><X /> Cancel job</button></PageHead>
    <div className="sesh-detail-layout"><div className="sesh-grid" style={{ alignContent: "start" }}>
      {item.state === "UNCERTAIN" && <div className="sesh-notice" style={{ background: "var(--amber-pale)", borderColor: "#eee0c3", color: "#80622b" }}><AlertCircle /> The office agent did not receive a clear response. This job may or may not have reached the printer. Check the printer before resubmitting to avoid duplicate pages.</div>}
      <section className="sesh-card sesh-panel"><CardTitle title="Job progress" description="A handoff state is not a print confirmation." /><div className="sesh-job-hero"><div><strong>{item.id}</strong><small>{item.printer}</small></div><StatusBadge state={item.state} /></div>
        <div className="sesh-timeline"><div className="sesh-timeline-row"><span className="sesh-timeline-dot" /><div><strong>Request created</strong><small>{item.time} · {item.owner}</small></div></div><div className="sesh-timeline-row"><span className="sesh-timeline-dot" /><div><strong>{item.state === "UNCERTAIN" ? "Agent response could not be confirmed" : item.state === "DOWNLOADED" ? "PDF downloaded by office agent" : item.state === "SENT_TO_PRINTER" ? "Sent to printer" : item.state === "CANCELLED" ? "Request cancelled" : "Waiting for office agent"}</strong><small>{item.state === "DOWNLOADED" ? "File delivery only; printer output remains unconfirmed." : item.state === "SENT_TO_PRINTER" ? "The agent handed off the PDF; printing is not confirmed." : "Local visual prototype state"}</small></div></div></div>
      </section></div>
      <div className="sesh-grid" style={{ alignContent: "start" }}><section className="sesh-card sesh-panel"><CardTitle title="Request details" /><dl className="sesh-detail-list"><div><dt>Requested by</dt><dd>{item.owner}</dd></div><div><dt>Document</dt><dd>{item.file}</dd></div><div><dt>Pages</dt><dd>{item.pages}</dd></div><div><dt>Copies</dt><dd>{item.copies}</dd></div><div><dt>Print mode</dt><dd>{item.color ? "Color" : "Black & white"}</dd></div><div><dt>Destination</dt><dd>{item.printer}</dd></div></dl></section>
      <section className="sesh-card sesh-panel"><CardTitle title="Device status" /><div className="sesh-device-row"><span className="sesh-device-icon"><Laptop /></span><div className="sesh-device-copy"><strong>Office agent</strong><small><i className="sesh-dot" />Connected</small></div></div><div className="sesh-device-row"><span className="sesh-device-icon"><Printer /></span><div className="sesh-device-copy"><strong>Printer</strong><small><i className="sesh-dot amber" />Availability is reported separately</small></div></div></section></div>
    </div>
  </>;
}

function WorkersPage({ onInvite, onReset }: { onInvite: () => void; onReset: () => void; }) {
  const people = [{ initials: "MC", name: "Mira Chen", email: "mira@seshat.studio", role: "Administrator", state: "Active" }, { initials: "DP", name: "Daniel Park", email: "daniel@seshat.studio", role: "Staff", state: "Active" }, { initials: "PN", name: "Priya Nair", email: "priya@seshat.studio", role: "Staff", state: "Active" }, { initials: "OW", name: "Oliver West", email: "oliver@seshat.studio", role: "Staff", state: "Invite pending" }];
  return <><PageHead eyebrow="PEOPLE & ACCESS" title="Workers" subtitle="Manage the people who can upload documents and request prints."><button className="sesh-btn secondary" onClick={onReset}><KeyRound /> Password reset</button><button className="sesh-btn primary" onClick={onInvite}><UserPlus /> Invite worker</button></PageHead>
    <div className="sesh-notice"><ShieldCheck /> Administrators manage company records and device setup. Staff see only their own documents and print requests.</div>
    <section className="sesh-card sesh-panel"><CardTitle title="Team members" description="4 workers · 1 administrator" /><div className="sesh-table-wrap"><table className="sesh-table"><thead><tr><th>Worker</th><th>Access</th><th>Status</th><th>Last active</th><th>Actions</th></tr></thead><tbody>{people.map((person, i) => <tr key={person.email}><td><div className="sesh-file-name"><span className="sesh-avatar">{person.initials}</span><span>{person.name}<small>{person.email}</small></span></div></td><td>{person.role}</td><td><StatusBadge state={person.state === "Active" ? "Converted" : "QUEUED"} /></td><td>{i === 0 ? "Just now" : i === 1 ? "Today, 9:43 AM" : "Yesterday"}</td><td><button className="sesh-inline-link" onClick={onReset}>Reset password</button></td></tr>)}</tbody></table></div></section>
  </>;
}
function PasswordReset({ onBack, notify }: { onBack: () => void; notify: (message: string) => void; }) {
  const [email, setEmail] = useState("mira@seshat.studio");
  function submit(event: FormEvent<HTMLFormElement>) { event.preventDefault(); notify(`Reset instructions previewed for ${email}`); }
  return <><PageHead eyebrow="ACCOUNT SECURITY" title="Password reset" subtitle="Send a reset link to a worker’s company email."><button className="sesh-btn secondary" onClick={onBack}><ArrowLeft /> Back to workers</button></PageHead><div className="sesh-notice"><Info /> This prototype does not send email. Submitting shows a local confirmation only.</div><form className="sesh-card sesh-panel" onSubmit={submit} style={{ maxWidth: 620 }}><div className="sesh-field"><label htmlFor="reset-email">Worker email address</label><input className="sesh-input" id="reset-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required /></div><div className="sesh-form-actions"><button className="sesh-btn secondary" type="button" onClick={onBack}>Cancel</button><button className="sesh-btn primary" type="submit"><KeyRound /> Preview reset email</button></div></form></>;
}
function CompanySettings({ companyName, setCompanyName, email, setEmail, notify, onOffice }: { companyName: string; setCompanyName: (s: string) => void; email: string; setEmail: (s: string) => void; notify: (s: string) => void; onOffice: () => void; }) {
  return <><PageHead eyebrow="ADMINISTRATION" title="Company settings" subtitle="Your team’s profile and coordination defaults."><button className="sesh-btn secondary" onClick={onOffice}><Laptop /> Office setup</button></PageHead><div className="sesh-notice"><Info /> Changes are editable in this preview but are not saved to a backend.</div><div className="sesh-detail-layout"><form className="sesh-card sesh-panel" onSubmit={(e) => { e.preventDefault(); notify("Settings updated in this preview only"); }}><CardTitle title="Company profile" description="Used across worker-facing screens and job records." /><div className="sesh-form-grid"><div className="sesh-field full"><label htmlFor="company-name">Company name</label><input id="company-name" className="sesh-input" value={companyName} onChange={(e) => setCompanyName(e.target.value)} /></div><div className="sesh-field full"><label htmlFor="company-email">Operations contact</label><input id="company-email" className="sesh-input" type="email" value={email} onChange={(e) => setEmail(e.target.value)} /></div><div className="sesh-field"><label htmlFor="timezone">Time zone</label><select id="timezone" className="sesh-select"><option>Pacific Time · Los Angeles</option><option>Mountain Time · Denver</option><option>Central Time · Chicago</option><option>Eastern Time · New York</option></select></div><div className="sesh-field"><label htmlFor="retention">Document retention</label><select id="retention" className="sesh-select"><option>30 days</option><option>90 days</option><option>1 year</option></select></div></div><div className="sesh-form-actions"><button className="sesh-btn primary" type="submit"><Check /> Apply in preview</button></div></form><section className="sesh-card sesh-panel"><CardTitle title="Access & safety" /><div className="sesh-setup-step"><span className="sesh-step-num"><LockKeyhole size={13} /></span><div><strong>Worker access</strong><p>Staff can view and manage only their own records.</p></div></div><div className="sesh-setup-step"><span className="sesh-step-num"><ShieldCheck size={13} /></span><div><strong>Administrator access</strong><p>Company-level people, office devices, and audit log.</p></div></div><div className="sesh-setup-step"><span className="sesh-step-num"><Activity size={13} /></span><div><strong>Audit trail</strong><p>Key activity records are visible to administrators.</p></div></div></section></div></>;
}
function OfficeSetup({ onAgent, onPrinter, agentConnected, printerAvailable }: { onAgent: () => void; onPrinter: () => void; agentConnected: boolean; printerAvailable: boolean; }) {
  return <><PageHead eyebrow="ADMINISTRATION · SETUP" title="Office & devices" subtitle="Keep computer-agent connectivity separate from printer availability." /><div className="sesh-grid" style={{ gridTemplateColumns: "repeat(2,minmax(0,1fr))" }}><section className="sesh-card sesh-panel"><CardTitle title="Office computer" description="The Sesh agent receives converted files for print handoff." /><div className="sesh-device-row"><span className="sesh-device-icon"><Laptop /></span><div className="sesh-device-copy"><strong>Studio-Mac-04</strong><small><i className={`sesh-dot ${agentConnected ? "" : "red"}`} />{agentConnected ? "Connected" : "Disconnected"} · Sesh Agent 2.8.1</small></div></div><button className="sesh-btn secondary" style={{ marginTop: 13 }} onClick={onAgent}>Configure computer agent <ArrowRight /></button></section><section className="sesh-card sesh-panel"><CardTitle title="Printer" description="A printer can be unavailable while its office computer stays connected." /><div className="sesh-device-row"><span className="sesh-device-icon"><Printer /></span><div className="sesh-device-copy"><strong>Canon imageRUNNER C5840</strong><small><i className={`sesh-dot ${printerAvailable ? "" : "amber"}`} />{printerAvailable ? "Available" : "Unavailable"} · Main office</small></div></div><button className="sesh-btn secondary" style={{ marginTop: 13 }} onClick={onPrinter}>Configure printer <ArrowRight /></button></section><section className="sesh-card sesh-panel" style={{ gridColumn: "1/-1" }}><CardTitle title="First-time setup checklist" description="A guided path to connect a team for the first time." /><div className="sesh-setup-step"><span className="sesh-step-num">1</span><div><strong>Company profile</strong><p>Set the team name and operations contact.</p></div><StatusBadge state="Converted" /></div><div className="sesh-setup-step"><span className="sesh-step-num">2</span><div><strong>Install the office agent</strong><p>Connect an office computer that can reach your printer.</p></div><StatusBadge state={agentConnected ? "Converted" : "UNCERTAIN"} /></div><div className="sesh-setup-step"><span className="sesh-step-num">3</span><div><strong>Check printer availability</strong><p>Confirm the printer is available on the office network.</p></div><StatusBadge state={printerAvailable ? "Converted" : "UNCERTAIN"} /></div></section></div></>;
}
function AgentSetup({ connected, setConnected, onBack, notify }: { connected: boolean; setConnected: (v: boolean) => void; onBack: () => void; notify: (s: string) => void; }) {
  return <><PageHead eyebrow="OFFICE DEVICES" title="Computer agent" subtitle="The agent receives print-ready PDFs and sends them to the selected printer."><button className="sesh-btn secondary" onClick={onBack}><ArrowLeft /> Office setup</button></PageHead><div className="sesh-notice"><Info /> Agent connectivity confirms this computer is reachable. It does not tell you whether a printer has paper or has produced pages.</div><section className="sesh-card sesh-panel" style={{ maxWidth: 760 }}><CardTitle title="Studio-Mac-04" description="Mac mini · Sesh Agent 2.8.1" /><div className="sesh-setup-step"><span className="sesh-step-num"><Laptop size={14} /></span><div style={{ flex: 1 }}><strong>Agent connection</strong><p>{connected ? "Connected · last check just now" : "Disconnected · queued jobs will wait for a connection"}</p></div><button className={`sesh-toggle ${connected ? "on" : ""}`} aria-label="Toggle office agent connection in preview" aria-pressed={connected} onClick={() => { setConnected(!connected); notify("Agent status changed in this preview"); }} /></div><div className="sesh-setup-step"><span className="sesh-step-num">1</span><div><strong>Install agent on office computer</strong><p>Use the signed installer from your organization’s approved software source.</p></div><StatusBadge state="Converted" /></div><div className="sesh-setup-step"><span className="sesh-step-num">2</span><div><strong>Pair this computer</strong><p>Confirm its company and office location before receiving print requests.</p></div><StatusBadge state={connected ? "Converted" : "QUEUED"} /></div><div className="sesh-form-actions"><button className="sesh-btn secondary" onClick={onBack}>Done</button><button className="sesh-btn primary" onClick={() => notify("Connection check simulated; no backend contacted")}><RefreshCw /> Check connection</button></div></section></>;
}
function PrinterSetup({ available, setAvailable, onBack, notify }: { available: boolean; setAvailable: (v: boolean) => void; onBack: () => void; notify: (s: string) => void; }) {
  return <><PageHead eyebrow="OFFICE DEVICES" title="Printer setup" subtitle="Printer readiness is its own status, separate from the computer agent."><button className="sesh-btn secondary" onClick={onBack}><ArrowLeft /> Office setup</button></PageHead><div className="sesh-notice"><Printer /> A printer being available means it can accept a handoff. Sesh does not claim that pages physically printed.</div><section className="sesh-card sesh-panel" style={{ maxWidth: 760 }}><CardTitle title="Canon imageRUNNER C5840" description="Main office · Network printer · Color, duplex" /><div className="sesh-setup-step"><span className="sesh-step-num"><Printer size={14} /></span><div style={{ flex: 1 }}><strong>Availability</strong><p>{available ? "Available to accept work" : "Unavailable · new jobs will wait"}</p></div><button className={`sesh-toggle ${available ? "on" : ""}`} aria-label="Toggle printer availability in preview" aria-pressed={available} onClick={() => { setAvailable(!available); notify("Printer availability changed in this preview"); }} /></div><div className="sesh-form-grid" style={{ marginTop: 18 }}><div className="sesh-field"><label htmlFor="printer-name">Printer name</label><input id="printer-name" className="sesh-input" defaultValue="Canon imageRUNNER C5840" /></div><div className="sesh-field"><label htmlFor="printer-location">Office location</label><input id="printer-location" className="sesh-input" defaultValue="Main office" /></div><div className="sesh-field"><label htmlFor="printer-queue">System queue</label><input id="printer-queue" className="sesh-input" defaultValue="canon-main-office" /></div><div className="sesh-field"><label htmlFor="printer-default">Default paper</label><select id="printer-default" className="sesh-select"><option>Letter</option><option>Legal</option><option>A4</option></select></div></div><div className="sesh-form-actions"><button className="sesh-btn secondary" onClick={onBack}>Done</button><button className="sesh-btn primary" onClick={() => notify("Printer test state simulated; no pages sent")}><Printer /> Test printer</button></div></section></>;
}
function AuditPage() {
  const rows = [
    ["Today, 10:48 AM", "Mira Chen", "Print request handed to printer", "SJ-10842"],
    ["Today, 10:16 AM", "Daniel Park", "Print delivery response uncertain", "SJ-10841"],
    ["Today, 9:52 AM", "Mira Chen", "Print request created", "SJ-10840"],
    ["Today, 9:18 AM", "Daniel Park", "Document converted to PDF", "DOC-2417"],
    ["Yesterday, 4:22 PM", "Priya Nair", "PDF downloaded by office agent", "SJ-10839"],
    ["Yesterday, 3:07 PM", "Mira Chen", "Document uploaded", "DOC-2413"],
  ];
  return <><PageHead eyebrow="ADMINISTRATION" title="Audit log" subtitle="A clear record of document and print coordination activity." /><div className="sesh-notice"><ShieldCheck /> Audit entries are sample records for this visual prototype. A send or agent download is not proof of printed output.</div><section className="sesh-card sesh-panel"><div className="sesh-toolbar"><div className="sesh-search"><Search /><input className="sesh-input" placeholder="Search activity…" aria-label="Search audit activity" onChange={(e) => { const term = e.target.value.toLowerCase(); document.querySelectorAll<HTMLElement>("[data-audit-row]").forEach((row) => { row.style.display = row.innerText.toLowerCase().includes(term) ? "" : "none"; }); }} /></div><button className="sesh-btn secondary" onClick={() => window.print()}><ArrowDownToLine /> Print log</button></div><div className="sesh-table-wrap"><table className="sesh-table"><thead><tr><th>When</th><th>Who</th><th>Activity</th><th>Reference</th></tr></thead><tbody>{rows.map((row) => <tr data-audit-row key={row[3]}><td>{row[0]}</td><td>{row[1]}</td><td>{row[2]}</td><td><span className="sesh-badge neutral">{row[3]}</span></td></tr>)}</tbody></table></div></section></>;
}

function Modal({ type, job, worker, onWorker, onClose, onCancel, onResolve, onInvite }: {
  type: "cancel" | "resolve" | "worker" | "invite"; job: Job; worker: { name: string; email: string; role: string }; onWorker: (v: { name: string; email: string; role: string }) => void; onClose: () => void; onCancel: () => void; onResolve: (outcome: "sent" | "retry") => void; onInvite: (e: FormEvent<HTMLFormElement>) => void;
}) {
  return <div className="sesh-modal-backdrop" role="presentation" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}><section className="sesh-modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><button className="sesh-modal-close" aria-label="Close dialog" onClick={onClose}><X /></button>
    {type === "cancel" && <><h2 id="modal-title">Cancel this print request?</h2><p>{job.id} · {job.file}. This changes only the visual preview. A downloaded job cannot be cancelled.</p><div className="sesh-form-actions"><button className="sesh-btn secondary" onClick={onClose}>Keep request</button><button className="sesh-btn danger" disabled={job.state === "DOWNLOADED"} onClick={onCancel}><X /> Cancel request</button></div></>}
    {type === "resolve" && <><h2 id="modal-title">Resolve delivery uncertainty</h2><p>Check the printer before choosing. “Sent to printer” is not confirmation that pages printed.</p><div className="sesh-notice"><AlertCircle /> Job {job.id} · {job.file}</div><div className="sesh-grid" style={{ gridTemplateColumns: "1fr 1fr" }}><button className="sesh-btn secondary" style={{ minHeight: 62, flexDirection: "column", gap: 3 }} onClick={() => onResolve("sent")}><Check /> Agent sent the file<p style={{ margin: 0, fontWeight: 400, fontSize: 9 }}>Mark sent; output still unconfirmed</p></button><button className="sesh-btn primary" style={{ minHeight: 62, flexDirection: "column", gap: 3 }} onClick={() => onResolve("retry")}><RefreshCw /> Not received yet<p style={{ margin: 0, fontWeight: 400, fontSize: 9 }}>Return to queue; check for duplicates</p></button></div></>}
    {(type === "invite" || type === "worker") && <><h2 id="modal-title">Invite a worker</h2><p>Preview a worker invitation. No email will be sent.</p><form onSubmit={onInvite}><div className="sesh-field" style={{ marginBottom: 12 }}><label htmlFor="worker-name">Full name</label><input className="sesh-input" id="worker-name" value={worker.name} onChange={(e) => onWorker({ ...worker, name: e.target.value })} required placeholder="e.g. Sam Rivera" /></div><div className="sesh-field" style={{ marginBottom: 12 }}><label htmlFor="worker-email">Work email</label><input className="sesh-input" id="worker-email" type="email" value={worker.email} onChange={(e) => onWorker({ ...worker, email: e.target.value })} required placeholder="sam@company.com" /></div><div className="sesh-field"><label htmlFor="worker-role">Access role</label><select className="sesh-select" id="worker-role" value={worker.role} onChange={(e) => onWorker({ ...worker, role: e.target.value })}><option>Staff</option><option>Administrator</option></select></div><div className="sesh-form-actions"><button type="button" className="sesh-btn secondary" onClick={onClose}>Cancel</button><button className="sesh-btn primary" type="submit"><UserPlus /> Preview invitation</button></div></form></>}
  </section></div>;
}
function Empty({ icon, title, detail, action }: { icon: React.ReactNode; title: string; detail: string; action?: React.ReactNode }) {
  return <div className="sesh-empty"><div className="sesh-empty-mark">{icon}</div><h3>{title}</h3><p>{detail}</p>{action}</div>;
}
function AuthScreen({ mode, setMode, onContinue }: { mode: "signin" | "setup"; setMode: (mode: "signin" | "setup") => void; onContinue: () => void; }) {
  const [showPassword, setShowPassword] = useState(false);
  return <div className="sesh-auth"><section className="sesh-auth-art"><div className="sesh-brand"><img src="/__mockup/images/seshat-logo.webp" alt="Seshat" /><div><strong>sesh</strong><small style={{ color: "#b6b9b9" }}>OFFICE PRINT, IN ORDER</small></div></div><div className="sesh-auth-quote"><p className="sesh-eyebrow">A QUIETER WAY TO GET IT PRINTED</p><h1>Your documents.<br />In good hands.</h1><p>One dependable place to convert files, coordinate office printers, and know exactly where every job stands.</p></div><div className="sesh-auth-meta">Seshat Studio · A calmer office workflow</div></section>
    <section className="sesh-auth-form-side"><form className="sesh-auth-form" onSubmit={(e) => { e.preventDefault(); onContinue(); }}><p className="sesh-eyebrow">{mode === "setup" ? "FIRST-TIME SETUP" : "WELCOME BACK"}</p><h2>{mode === "setup" ? "Set up your workspace" : "Sign in to Sesh"}</h2><p>{mode === "setup" ? "Create the first administrator account for your team." : "Use your company account to continue."}</p>{mode === "setup" && <div className="sesh-field"><label htmlFor="auth-company">Company name</label><input id="auth-company" className="sesh-input" required placeholder="Your company" /></div>}<div className="sesh-field"><label htmlFor="auth-email">Work email</label><input className="sesh-input" id="auth-email" type="email" required defaultValue={mode === "signin" ? "mira@seshat.studio" : ""} placeholder="you@company.com" /></div><div className="sesh-field"><label htmlFor="auth-password">Password</label><div style={{ display: "flex", position: "relative" }}><input className="sesh-input" id="auth-password" type={showPassword ? "text" : "password"} required defaultValue={mode === "signin" ? "seshpreview" : ""} placeholder="At least 8 characters" style={{ paddingRight: 73 }} /><button type="button" className="sesh-inline-link" onClick={() => setShowPassword(!showPassword)} style={{ position: "absolute", right: 7, top: 8 }}>{showPassword ? "Hide" : "Show"}</button></div></div>{mode === "signin" && <div style={{ textAlign: "right", marginTop: -6, marginBottom: 13 }}><button className="sesh-auth-link" type="button" onClick={() => setMode("setup")}>First time here?</button></div>}<button className="sesh-btn primary" style={{ width: "100%", minHeight: 42 }} type="submit">{mode === "setup" ? "Create workspace" : "Sign in"} <ArrowRight /></button><div className="sesh-auth-foot">Visual prototype · authentication is simulated locally</div>{mode === "setup" && <div className="sesh-auth-foot"><button className="sesh-auth-link" type="button" onClick={() => setMode("signin")}>Back to sign in</button></div>}</form></section>
  </div>;
}
